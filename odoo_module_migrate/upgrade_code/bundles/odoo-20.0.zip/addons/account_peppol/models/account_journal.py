from odoo import _, api, fields, models
from odoo.exceptions import ValidationError
from odoo.addons.account.models.company import PEPPOL_DEFAULT_COUNTRIES


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    account_peppol_proxy_state = fields.Selection(related='company_id.account_peppol_proxy_state')
    is_peppol_journal = fields.Boolean(string="Account used for Peppol", default=False)

    @api.constrains('type')
    def _check_type_for_peppol_journal(self):
        for journal in self:
            if journal.is_peppol_journal and journal.type != 'purchase':
                raise ValidationError(_("You can't change the type of a journal used for Peppol invoice reception to"
                                  "a type different than 'Purchase'.\nPlease change the journal used for Peppol"
                                  " reception before changing the type of this journal."))

    @api.depends('account_peppol_proxy_state')
    def _compute_show_refresh_out_einvoices_status_button(self):
        # EXTENDS 'account'
        super()._compute_show_refresh_out_einvoices_status_button()
        sender_states = self.env['account_edi_proxy_client.user']._get_can_send_domain()

        self.filtered(lambda j: (
            j.account_peppol_proxy_state in sender_states
            and (
                j.type == 'sale'
                or (
                    j.type == 'purchase'
                    and j.is_self_billing
                )
            )
        )).show_refresh_out_einvoices_status_button = True

    @api.depends('is_peppol_journal', 'account_peppol_proxy_state')
    def _compute_show_fetch_in_einvoices_button(self):
        # EXTENDS 'account'
        super()._compute_show_fetch_in_einvoices_button()

        self.filtered(lambda j: (
            j.is_peppol_journal
            and j.account_peppol_proxy_state == 'receiver'
            and j.type == 'purchase'
            and not j.is_self_billing
        )).show_fetch_in_einvoices_button = True

    def button_fetch_in_einvoices(self):
        # EXTENDS 'account'
        super().button_fetch_in_einvoices()
        edi_users = self.env['account_edi_proxy_client.user'].search([
            ('company_id.account_peppol_proxy_state', '=', 'receiver'),
            ('company_id', 'in', self.company_id.ids),
            ('proxy_type', 'in', self.env['account_edi_proxy_client.user']._get_peppol_proxy_types()),
        ])
        edi_users._peppol_get_new_documents()

    def button_refresh_out_einvoices_status(self):
        # EXTENDS 'account'
        super().button_refresh_out_einvoices_status()
        can_send = self.env['account_edi_proxy_client.user']._get_can_send_domain()
        edi_users = self.env['account_edi_proxy_client.user'].search([
            ('company_id.account_peppol_proxy_state', 'in', can_send),
            ('company_id', 'in', self.company_id.ids),
            ('proxy_type', 'in', self.env['account_edi_proxy_client.user']._get_peppol_proxy_types()),
        ])
        edi_users._peppol_get_message_status()

    def _get_onboarding_action_data(self):
        self.ensure_one()
        if self.country_code not in PEPPOL_DEFAULT_COUNTRIES:
            return super()._get_onboarding_action_data()
        if self.company_id.account_peppol_proxy_state == 'not_registered':
            return {
                'title': self.env._("Activate Peppol"),
                'action': self.company_id._action_open_peppol_form(),
            }
        return {
            'title': self.env._("Peppol Settings"),
            'action': self.env.ref('account.action_account_config')._get_action_dict(),
        }
