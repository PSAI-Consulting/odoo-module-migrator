# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api
from odoo.tools import SQL


class AccountMove(models.Model):
    _inherit = "account.move"

    debit_origin_id = fields.Many2one('account.move', 'Original Invoice Debited', readonly=True, copy=False, index='btree_not_null')
    debit_origin_move_type = fields.Selection(related='debit_origin_id.move_type', string="Debit Origin Move Type")  # String defined to avoid runbot error about same string on different fields.
    debit_note_ids = fields.One2many('account.move', 'debit_origin_id', 'Debit Notes',
                                     help="The debit notes created for this invoice")
    debit_note_count = fields.Integer('Number of Debit Notes', compute='_compute_debit_count')

    @api.depends('debit_note_ids')
    def _compute_debit_count(self):
        debit_data = self.env['account.move']._read_group([('debit_origin_id', 'in', self.ids)],
                                                        ['debit_origin_id'], ['__count'])
        data_map = {debit_origin.id: count for debit_origin, count in debit_data}
        for inv in self:
            inv.debit_note_count = data_map.get(inv.id, 0.0)

    def action_view_debit_notes(self):
        return self.debit_note_ids._get_records_action(
            name=self.env._("Debit Notes"),
        )

    def action_open_debit_note_origin_entry(self):
        return self.debit_origin_id._get_records_action(
            name=self.env._("Invoices") if self.is_sale_document(include_receipts=True) else self.env._("Vendor Bills"),
        )

    def action_debit_note(self):
        action = self.env.ref('account_debit_note.action_view_account_move_debit')._get_action_dict()
        return action

    def _get_last_sequence_domain(self, relaxed=False):
        condition = super()._get_last_sequence_domain(relaxed)
        if self.journal_id.debit_sequence:
            condition = SQL("%s AND debit_origin_id IS %s", condition, SQL("NOT NULL") if self.debit_origin_id else SQL("NULL"))
        return condition

    def _get_starting_sequence(self):
        starting_sequence = super()._get_starting_sequence()
        if (
            self.journal_id.debit_sequence
            and self.debit_origin_id
            and self.move_type in ("in_invoice", "out_invoice")
        ):
            starting_sequence = "D" + starting_sequence
        return starting_sequence
