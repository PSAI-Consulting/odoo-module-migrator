# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_account
from . import account_move
from . import account_tax
from . import fleet_vehicle
from . import fleet_vehicle_log_services
