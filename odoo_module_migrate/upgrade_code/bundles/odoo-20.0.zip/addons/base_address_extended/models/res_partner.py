# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models
from odoo.tools.business_data import street_split


class ResPartner(models.Model):
    _inherit = 'res.partner'

    street_name = fields.Char(
        'Street Name', compute='_compute_street_data', inverse='_inverse_street_data', store=True)
    street_number = fields.Char(
        'House', compute='_compute_street_data', inverse='_inverse_street_data', store=True)
    street_number2 = fields.Char(
        'Door', compute='_compute_street_data', inverse='_inverse_street_data', store=True)

    city_id = fields.Many2one(comodel_name='res.city', string='City ID')
    country_enforce_cities = fields.Boolean(related='country_id.enforce_cities')

    @api.model
    def _address_fields(self):
        return super()._address_fields() + ['city_id']

    def _inverse_street_data(self):
        """ update self.street based on street_name, street_number and street_number2 """
        for partner in self:
            street = ((partner.street_name or '') + " " + (partner.street_number or '')).strip()
            if partner.street_number2:
                street = street + " - " + partner.street_number2
            partner.street = street

    @api.depends('street')
    def _compute_street_data(self):
        """Splits street value into sub-fields.
        Recomputes the fields of STREET_FIELDS when `street` of a partner is updated"""
        for partner in self:
            partner.update(street_split(partner.street))

    def _get_street_split(self):
        self.ensure_one()
        return {
            'street_name': self.street_name,
            'street_number': self.street_number,
            'street_number2': self.street_number2
        }

    @api.onchange('city_id')
    def _onchange_city_id(self):
        if self.city_id:
            self.city = self.city_id.name
            if self.city_id.state_id:
                self.state_id = self.city_id.state_id
            if not (self.parent_id and self.city_id == self.parent_id.city_id and self.zip == self.parent_id.zip) and self.city_id.zipcode:
                self.zip = self.city_id.zipcode
        elif self._origin:
            self.city = False
            self.zip = False
            self.state_id = False

    @api.onchange('country_id')
    def _onchange_country_id(self):
        super()._onchange_country_id()
        if self.country_id and self.country_id != self.city_id.country_id:
            self.city_id = False

    @api.model
    def _get_res_city_by_name(self, name, country_id):
        ResCity = self.env['res.city']
        if not name or not country_id:
            return ResCity

        if self.env.user._is_public():
            ResCity = ResCity.sudo()

        return ResCity.search([
            ('name', '=ilike', name),
            ('country_id', '=', country_id),
        ], limit=1)
