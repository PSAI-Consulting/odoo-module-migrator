from odoo import _, api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    account_peppol_edi_user = fields.Many2one(related='company_id.account_peppol_edi_user')
    account_peppol_edi_mode = fields.Selection(related='account_peppol_edi_user.edi_mode')
    account_peppol_contact_email = fields.Char(
        compute='_compute_account_peppol_contact_email',
        inverse='_inverse_account_peppol_contact_email',
    )

    account_peppol_eas = fields.Selection(related='company_id.peppol_eas', readonly=False)
    account_peppol_edi_identification = fields.Char(related='account_peppol_edi_user.edi_identification')
    account_peppol_endpoint = fields.Char(related='company_id.peppol_endpoint', readonly=False)
    account_peppol_migration_key = fields.Char(related='company_id.account_peppol_migration_key', readonly=False)
    account_peppol_phone_number = fields.Char(related='company_id.account_peppol_phone_number', readonly=False)
    account_peppol_proxy_state = fields.Selection(related='company_id.account_peppol_proxy_state', readonly=False)
    account_peppol_purchase_journal_id = fields.Many2one(related='company_id.peppol_purchase_journal_id', readonly=False)
    peppol_external_provider = fields.Char(related='company_id.peppol_external_provider', readonly=False)
    peppol_purchase_journal_required = fields.Boolean(compute='_compute_peppol_purchase_journal_required')
    peppol_use_parent_company = fields.Boolean(compute='_compute_peppol_use_parent_company')
    peppol_parent_company_name = fields.Char(compute='_compute_peppol_use_parent_company')
    account_is_token_out_of_sync = fields.Boolean(related='account_peppol_edi_user.is_token_out_of_sync', readonly=False)
    peppol_participation_role = fields.Selection(
        selection=[
            ('sending_and_receiving', 'Sending & Receiving'),
            ('sending_only', 'Sending Only'),
        ],
        compute='_compute_peppol_participation_role',
        inverse='_inverse_peppol_participation_role',
    )

    def _get_peppol_proxy_type(self):
        self.ensure_one()
        return self.account_peppol_edi_user.proxy_type

    # -------------------------------------------------------------------------
    # COMPUTE METHODS
    # -------------------------------------------------------------------------

    @api.depends('company_id.peppol_parent_company_id')
    def _compute_peppol_use_parent_company(self):
        for setting in self:
            setting.peppol_use_parent_company = (
                setting.company_id != setting.company_id.peppol_parent_company_id
                and setting.company_id.peppol_can_send
                and setting.company_id.peppol_parent_company_id.peppol_can_send
            )
            if setting.peppol_use_parent_company:
                setting.peppol_parent_company_name = setting.company_id.peppol_parent_company_id.name
            else:
                setting.peppol_parent_company_name = None

    @api.depends('account_peppol_proxy_state')
    def _compute_peppol_participation_role(self):
        for record in self:
            state = record.company_id.account_peppol_proxy_state
            if state == 'sender':
                record.peppol_participation_role = 'sending_only'
            elif state in ('smp_registration', 'receiver'):
                record.peppol_participation_role = 'sending_and_receiving'
            else:
                record.peppol_participation_role = False

    def _inverse_peppol_participation_role(self):
        for record in self:
            if record.account_peppol_edi_user:
                if record.peppol_participation_role == 'sending_only' and record.account_peppol_proxy_state != 'sender':
                    # Reset the participant back to sender and unregister it from the SMP
                    record.account_peppol_edi_user._peppol_deregister_participant_to_sender()
                elif record.peppol_participation_role == 'sending_and_receiving' and record.account_peppol_proxy_state not in ('smp_registration', 'receiver'):
                    # Set the participant to sender as well as register it on the SMP
                    record.account_peppol_edi_user._peppol_register_sender_as_receiver()
                    record.account_peppol_edi_user._peppol_get_participant_status()

    @api.depends('company_id.account_peppol_contact_email')
    def _compute_account_peppol_contact_email(self):
        for record in self:
            record.account_peppol_contact_email = record.company_id.account_peppol_contact_email

    def _inverse_account_peppol_contact_email(self):
        for record in self:
            company = record.company_id
            if record.account_peppol_contact_email == company.account_peppol_contact_email:
                continue

            # Update company field
            company.account_peppol_contact_email = record.account_peppol_contact_email

            # No Peppol user yet: keep new value but skip proxy sync.
            if not record.account_peppol_edi_user:
                continue

            # Sync with IAP (Peppol proxy)
            params = {
                'update_data': {
                    'peppol_contact_email': record.account_peppol_contact_email,
                }
            }
            record.account_peppol_edi_user._call_peppol_proxy(
                endpoint=record.account_peppol_edi_user._get_peppol_proxy_endpoint('1/update_user'),
                params=params,
            )

    @api.depends('account_peppol_proxy_state', 'peppol_participation_role')
    def _compute_peppol_purchase_journal_required(self):
        for config in self:
            config.peppol_purchase_journal_required = config.peppol_participation_role == 'sending_and_receiving'

    # -------------------------------------------------------------------------
    # BUSINESS ACTIONS
    # -------------------------------------------------------------------------

    def action_open_peppol_form(self):
        registration_wizard = self.env['peppol.registration'].create({'company_id': self.company_id.id})
        registration_action = registration_wizard._action_open_peppol_form(reopen=False)
        return registration_action

    # Deprecated
    def button_open_peppol_config_wizard(self):
        view = self.env.ref('account_peppol.peppol_config_wizard_form').sudo()
        # TODO remove in master this hack to have the possibility of being only a sender
        if 'button_peppol_reset_to_sender' not in view.arch_db:
            view.reset_arch(mode="hard")
        return {
            'type': 'ir.actions.act_window',
            'name': 'Advanced Peppol Configuration',
            'res_model': 'peppol.config.wizard',
            'view_mode': 'form',
            'target': 'new',
        }

    def button_peppol_disconnect_branch_from_parent(self):
        self.ensure_one()
        previous_parent_company_name = self.company_id.peppol_parent_company_id.name
        self.account_peppol_edi_user._peppol_deregister_participant()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': None,
                'type': 'success',
                'message': _("Disconnected this branch company peppol configuration from %s.", previous_parent_company_name),
                'next': {'type': 'ir.actions.act_window_close'},
            }
        }

    # Dreprecated
    def button_peppol_register_sender_as_receiver(self):
        """Register the existing user as a receiver."""
        self.ensure_one()
        return self.env['peppol.config.wizard'].new().button_peppol_register_sender_as_receiver()

    def button_reconnect_this_database(self):
        """Re-establish an out-of-sync connection"""
        self.ensure_one()
        self.account_peppol_edi_user._peppol_out_of_sync_reconnect_this_database()

    def button_disconnect_this_database(self):
        """Disconnect the current database from the Peppol network.
        This does not delete or affect the IAP connection, which will remain intact.
        So don't use this to deregister the participant/connection.
        """
        self.ensure_one()
        self.account_peppol_edi_user._peppol_out_of_sync_disconnect_this_database()

    def button_peppol_deregister(self):
        """Unregister the user from Peppol network."""
        self.ensure_one()

        if self.account_peppol_edi_user:
            self.account_peppol_edi_user._peppol_deregister_participant()
        return True

    def button_peppol_reregister(self):
        self.ensure_one()
        if self.account_peppol_edi_user:
            self.account_peppol_edi_user._peppol_deregister_participant()
        else:
            self.company_id._reset_peppol_configuration()
        return self.action_open_peppol_form()

    @api.model
    def _get_pdp_module_info(self):
        pdp_module = self.env['ir.module.module'].sudo()._get('l10n_fr_pdp')  # avoid returning it since it is sudoed
        module_name = self.env._("France - E-Invoicing (Approved Platform)")
        if pdp_module:
            action = pdp_module._get_records_action()
            action_name = self.env._("Go to module")
            warning = self.env._("To use the Approved Platform for French E-Invoicing install the module '%s'.", module_name)
        else:
            action = self.env.ref('base.action_view_base_module_update').id
            action_name = self.env._("Update App List")
            warning = self.env._("To use the Approved Platform for French E-Invoicing install the module '%s'.\n"
                                 "The module was not found. Please update the app list first.",
                                 module_name)
        return {
            'is_installed': pdp_module and pdp_module.state == 'installed',
            'module_name': module_name,
            'action': action,
            'action_name': action_name,
            'warning_message': warning,
        }
