# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging
import re
from datetime import timedelta
from lxml import etree

from odoo import _, api, fields, models, modules, tools
from odoo.exceptions import UserError
from odoo.tools import format_list
from odoo.addons.account_edi_proxy_client.models.account_edi_proxy_user import AccountEdiProxyError
from odoo.addons.account_peppol.tools.demo_utils import handle_demo
from odoo.addons.account_peppol.tools.peppol_errors import render_peppol_errors

_logger = logging.getLogger(__name__)
BATCH_SIZE = 50
REMOVE_EMBEDDED_DOCUMENT_BINARY_OBJECT_RE = re.compile(
    rb'(<(?P<tag>(?:[A-Za-z_][A-Za-z0-9_.-]*:)?EmbeddedDocumentBinaryObject)\b[^<>]*>)'
    rb'(?P<data>.*?)'
    rb'(</(?P=tag)\s*>)',
    re.DOTALL,
)


class AccountEdiProxyClientUser(models.Model):
    _inherit = 'account_edi_proxy_client.user'

    peppol_verification_code = fields.Char(string='SMS verification code')  # TODO remove in master
    proxy_type = fields.Selection(selection_add=[('peppol', 'PEPPOL')], ondelete={'peppol': 'cascade'})

    # -------------------------------------------------------------------------
    # HELPER METHODS
    # -------------------------------------------------------------------------

    @api.model
    def _get_peppol_proxy_types(self):
        return ['peppol']

    def _get_proxy_urls(self):
        urls = super()._get_proxy_urls()
        urls['peppol'] = {
            'prod': 'https://peppol.api.odoo.com',
            'test': 'https://peppol.test.odoo.com',
            'demo': 'demo',
        }
        return urls

    def _get_peppol_proxy_endpoint(self, endpoint, proxy_type=None):
        """The `endpoint` should include the number; be like `2/participant_status`"""
        if not proxy_type:
            self.ensure_one()
            proxy_type = self.proxy_type
        return f"/api/{proxy_type}/{endpoint.lstrip('/')}"

    @handle_demo
    def _call_peppol_proxy(self, endpoint, params=None):
        self.ensure_one()
        peppol_proxy_types = self._get_peppol_proxy_types()
        if self.proxy_type not in peppol_proxy_types:
            proxy_type_map = dict(self._fields['proxy_type']._description_selection(self.env))
            proxy_types = [proxy_type_map[proxy_type] for proxy_type in peppol_proxy_types]
            raise UserError(self.env._('EDI user should be of one of the following types: %s', format_list(self.env, proxy_types, 'or')))

        errors = {
            'code_incorrect': _('The verification code is not correct'),
            'code_expired': _('This verification code has expired. Please request a new one.'),
            'too_many_attempts': _('Too many attempts to request an SMS code. Please try again later.'),
        }

        params = params or {}
        try:
            response = self._make_request(
                f"{self._get_server_url()}{endpoint}",
                params=params,
            )
        except AccountEdiProxyError as e:
            if (
                e.code == 'no_such_user'
                and not self.active
                and not self.company_id.account_edi_proxy_client_ids.filtered(lambda u: u.proxy_type == self.proxy_type)
            ):
                self.company_id.write({
                    'account_peppol_proxy_state': 'not_registered',
                    'account_peppol_migration_key': False,
                })
                # commit the above changes before raising below
                if not modules.module.current_test:
                    self.env.cr.commit()
                raise UserError(_('We could not find a user with this information on our server. Please check your information.'))
            raise UserError(e.message)

        if 'error' in response:
            error_code = response['error'].get('code')
            error_message = response['error'].get('message') or response['error'].get('data', {}).get('message')
            raise UserError(errors.get(error_code) or error_message or _('Connection error, please try again later.'))
        return response

    @api.model
    def _get_can_send_domain(self):
        return ('sender', 'smp_registration', 'receiver')

    @handle_demo
    def _check_company_on_peppol(self, company, edi_identification):
        if (
            not company.sudo().account_peppol_migration_key
            and (participant_info := company.partner_id._peppol_lookup_participant(edi_identification)) is not None
            and company.partner_id._check_peppol_participant_exists(participant_info, edi_identification, check_company=True)
        ):
            error_msg = _(
                "A participant with these details has already been registered on the network. "
                "If you have previously registered to a Peppol service, please deregister."
            )
            raise UserError(error_msg)

    # -------------------------------------------------------------------------
    # CRONS
    # -------------------------------------------------------------------------

    def _cron_peppol_get_new_documents(self):
        edi_users = self.search([('company_id.account_peppol_proxy_state', '=', 'receiver'), ('proxy_type', 'in', self._get_peppol_proxy_types())])
        edi_users._peppol_get_new_documents()

    def _cron_peppol_get_message_status(self):
        edi_users = self.search([('company_id.account_peppol_proxy_state', 'in', self._get_can_send_domain()), ('proxy_type', 'in', self._get_peppol_proxy_types())])
        edi_users._peppol_get_message_status()

    def _cron_peppol_get_participant_status(self):
        edi_users = self.search([('proxy_type', 'in', self._get_peppol_proxy_types())])
        edi_users._peppol_get_participant_status()

        # throughout the registration process, we need to check the status more frequently
        if self.search_count([('company_id.account_peppol_proxy_state', '=', 'smp_registration')], limit=1):
            self.env.ref('account_peppol.ir_cron_peppol_get_participant_status')._trigger(at=fields.Datetime.now() + timedelta(hours=1))

    # -------------------------------------------------------------------------
    # BUSINESS ACTIONS
    # -------------------------------------------------------------------------

    def _get_proxy_identification(self, company, proxy_type):
        if proxy_type == 'peppol':
            if not company.peppol_eas or not company.peppol_endpoint:
                raise UserError(
                    _("Please fill in the EAS code and the Participant ID code."))
            return f'{company.peppol_eas}:{company.peppol_endpoint}'
        return super()._get_proxy_identification(company, proxy_type)

    def _peppol_import_invoice(self, attachment, partner_endpoint, peppol_state, uuid):
        """Save new documents in an accounting journal, when one is specified on the company.

        :param attachment: the new document
        :param partner_endpoint: DEPRECATED - to be removed in master
        :param peppol_state: the state of the received Peppol document
        :param uuid: the UUID of the Peppol document
        :return: the created invoice if the document was saved, `False` if it was not
        """
        self.ensure_one()
        journal, move_type = self._peppol_get_import_journal_and_move_type(attachment)
        if not journal:
            return False

        move = self.env['account.move'].create({
            'journal_id': journal.id,
            'move_type': move_type,
            'peppol_move_state': peppol_state,
            'peppol_message_uuid': uuid,
        })
        if 'is_in_extractable_state' in move._fields:
            move.is_in_extractable_state = False
        try:
            move._extend_with_attachments(attachment, new=True)
            move._message_log(
                body=self.env._(
                    "%(proxy_type)s document (UUID: %(uuid)s) has been received successfully",
                    proxy_type=dict(self._fields['proxy_type']._description_selection(self.env))[self.proxy_type],
                    uuid=uuid,
                ),
                attachment_ids=attachment.ids,
            )
            move._autopost_bill()
        except Exception:
            _logger.exception("Unexpected error occurred during the import of bill with id %s", move.id)

        attachment.write({'res_model': 'account.move', 'res_id': move.id})
        return move

    def _get_type_code(self, attachment):
        try:
            xml_tree = etree.fromstring(attachment.raw)
        except etree.XMLSyntaxError:
            xml_tree = etree.fromstring(REMOVE_EMBEDDED_DOCUMENT_BINARY_OBJECT_RE.sub(b'', attachment.raw))
            _logger.warning("The Peppol XML file was trimmed after huge node tree error for attachment ID %s", attachment.id)
        return xml_tree.findtext('.//{*}InvoiceTypeCode') or xml_tree.findtext('.//{*}CreditNoteTypeCode')

    def _peppol_get_import_journal_and_move_type(self, attachment):
        # Self-billed invoices are invoices which your customer creates on your behalf and sends you via Peppol.
        # In this case, the invoice needs to be created as an out_invoice in a sale journal.
        self.ensure_one()
        journal = self.company_id.peppol_purchase_journal_id
        move_type = 'in_invoice'
        error_msg = "The Peppol XML file is invalid or empty for attachment ID %s"
        try:
            type_code = self._get_type_code(attachment)
        except (etree.XMLSyntaxError, ValueError):
            _logger.exception(error_msg, attachment.id)
            return journal, move_type

        if type_code in ['389', '527', '261']:
            # 389/527: Self-billing invoice; 261: Self-billing credit note
            journal = self._peppol_get_import_sale_journal(self.company_id)
            move_type = 'out_invoice' if type_code in ['389', '527'] else 'out_refund'
        return journal, move_type

    def _peppol_get_duplicate_message_uuids(self, message_uuids):
        self.ensure_one()
        return set(
            self.env['account.move'].search([
                ('peppol_message_uuid', 'in', message_uuids),
                ('company_id', '=', self.company_id.id),
            ])
            .mapped('peppol_message_uuid')
        )

    def _peppol_get_new_documents(self):
        # Context added to not break stable policy: useful to tweak on databases processing large invoices
        job_count = self._context.get('peppol_crons_job_count') or BATCH_SIZE
        need_retrigger = False
        params = {
            'domain': {
                'direction': 'incoming',
                'errors': False,
            }
        }
        for edi_user in self:
            edi_user = edi_user.with_company(edi_user.company_id)
            params['domain']['receiver_identifier'] = edi_user.edi_identification
            try:
                # request all messages that haven't been acknowledged
                messages = edi_user._call_peppol_proxy(
                    endpoint=edi_user._get_peppol_proxy_endpoint('1/get_all_documents'),
                    params=params,
                )
            except AccountEdiProxyError as e:
                _logger.error(
                    'Error while receiving the document from Peppol Proxy: %s', e.message)
                continue

            received_messages = messages.get('messages', [])
            # Edge case: self-addressed messages (sender == receiver), i.e. a company genuinely
            # invoicing itself. The outgoing invoice already carries the message UUID, so the
            # duplicate check would wrongly discard the incoming document.
            # Exclude those messages from the check so the vendor bill can still be created.
            uuids_to_check = [
                message['uuid'] for message in received_messages
                if message.get('sender') and message['sender'] != message['receiver']
            ]
            # Acknowledge the duplicates on IAP side.
            if duplicate_message_uuids := edi_user._peppol_get_duplicate_message_uuids(uuids_to_check):
                edi_user._call_peppol_proxy(
                    endpoint=edi_user._get_peppol_proxy_endpoint('1/ack'),
                    params={'message_uuids': list(duplicate_message_uuids)},
                )
                _logger.info(
                    "Messages with UUID %s could not be imported because they are identified as duplicates",
                    ', '.join(duplicate_message_uuids)
                )

            # Remove the duplicates
            message_uuids = [
                message['uuid'] for message in received_messages
                if message['uuid'] not in duplicate_message_uuids
            ]
            if not message_uuids:
                continue

            need_retrigger = need_retrigger or len(message_uuids) > job_count
            message_uuids = message_uuids[:job_count]

            # retrieve attachments for filtered messages
            all_messages = edi_user._call_peppol_proxy(
                endpoint=edi_user._get_peppol_proxy_endpoint('1/get_document'),
                params={'message_uuids': message_uuids},
            )

            processed_uuids, moves = edi_user._peppol_process_new_messages(all_messages)

            if not tools.config['test_enable']:
                self.env.cr.commit()
            if processed_uuids:
                edi_user._call_peppol_proxy(
                    endpoint=edi_user._get_peppol_proxy_endpoint('1/ack'),
                    params={'message_uuids': processed_uuids},
                )
                edi_user._peppol_post_process_new_messages(moves)

        if need_retrigger:
            self.env.ref('account_peppol.ir_cron_peppol_get_new_documents')._trigger()

    def _peppol_get_filetype(self, content):
        return "xml", "application/xml"

    def _peppol_get_decoded_document(self, content):
        enc_key = content["enc_key"]
        document_content = content["document"]
        return self._decrypt_data(document_content, enc_key)

    def _peppol_get_import_sale_journal(self, company):
        return self.env['account.journal'].search(
            [
                *self.env['account.journal']._check_company_domain(company),
                ('type', '=', 'sale'),
            ],
            limit=1,
        )

    def _peppol_process_new_messages(self, messages):
        self.ensure_one()
        processed_uuids = []
        moves = self.env['account.move']
        for uuid, content in messages.items():
            fileextension, mimetype = self._peppol_get_filetype(content)
            filename = content["filename"] or 'attachment'  # default to attachment, which should not usually happen
            attachment = self.env["ir.attachment"].create(
                {
                    "name": f"{filename}.{fileextension}",
                    "raw": self._peppol_get_decoded_document(content),
                    "type": "binary",
                    "mimetype": mimetype,
                }
            )
            if move := self._peppol_import_invoice(attachment, None, content['state'], uuid):
                # Only acknowledge when we saved the document somewhere
                processed_uuids.append(uuid)
                if not isinstance(move, bool):
                    moves += move
        return processed_uuids, moves

    def _peppol_post_process_new_messages(self, moves):
        self.ensure_one()
        for partner in moves.partner_id.filtered(lambda partner: partner.peppol_verification_state in ('not_verified', False)):
            partner.button_account_peppol_check_partner_endpoint()

    def _peppol_get_message_status(self):
        # Context added to not break stable policy: useful to tweak on databases processing large invoices
        job_count = self._context.get('peppol_crons_job_count') or BATCH_SIZE
        need_retrigger = False
        for edi_user in self:
            edi_user = edi_user.with_company(edi_user.company_id)
            documents = edi_user._peppol_get_documents_for_status(job_count)
            if not documents:
                continue
            need_retrigger = need_retrigger or len(documents) > job_count
            uuid_to_record = {document.peppol_message_uuid: document for document in documents[:job_count]}
            messages_to_process = edi_user._call_peppol_proxy(
                endpoint=edi_user._get_peppol_proxy_endpoint('1/get_document'),
                params={'message_uuids': list(uuid_to_record)},
            )

            processed_message_uuids = edi_user._peppol_process_messages_status(messages_to_process, uuid_to_record)

            if processed_message_uuids:
                edi_user._call_peppol_proxy(
                    endpoint=edi_user._get_peppol_proxy_endpoint('1/ack'),
                    params={'message_uuids': processed_message_uuids},
                )
        if need_retrigger:
            self.env.ref('account_peppol.ir_cron_peppol_get_message_status')._trigger()

    def _peppol_get_documents_for_status(self, batch_size):
        self.ensure_one()
        edi_user_moves = self.env['account.move'].search(
            [
                ('peppol_move_state', '=', 'processing'),
                ('company_id', '=', self.company_id.id),
            ],
            limit=batch_size + 1,
        )
        return list(edi_user_moves)

    def _peppol_process_messages_status(self, messages, uuid_to_record):
        self.ensure_one()
        processed_message_uuids = []
        for uuid, content in messages.items():
            move = uuid_to_record[uuid]
            if content.get('error'):
                if content['error'].get('code') == 702:
                    # "Peppol request not ready" error:
                    # thrown when the IAP is still processing the message
                    continue
                move.peppol_move_state = 'error'
                move._message_log(body=self._peppol_get_message_status_error_body(move, content['error']))
                processed_message_uuids.append(uuid)
                continue

            move.peppol_move_state = content['state']
            move._message_log(body=self._peppol_get_message_status_update_body(move, content))
            processed_message_uuids.append(uuid)
        return processed_message_uuids

    def _peppol_get_message_status_error_body(self, move, error):
        return render_peppol_errors(move, error)

    def _peppol_get_message_status_update_body(self, move, content):
        self.ensure_one()
        return self.env._('Peppol status update: %s', content['state'])

    def _peppol_process_participant_status(self, proxy_user):
        self.ensure_one()
        local_state = {
            'draft': 'not_registered',
            'sender': 'sender',
            'smp_registration': 'smp_registration',
            'receiver': 'receiver',
            'rejected': 'rejected',
        }.get(proxy_user.get('peppol_state'))

        if local_state == 'not_registered':
            self.sudo().company_id._reset_peppol_configuration()
        elif local_state:
            self.company_id.account_peppol_proxy_state = local_state
        else:
            _logger.warning("Received unknown Peppol state '%s' for EDI proxy user id=%s", proxy_user.get('peppol_state'), self.id)

    def _peppol_get_participant_status(self):
        for edi_user in self:
            edi_user = edi_user.with_company(edi_user.company_id)
            if edi_user.proxy_type not in self._get_peppol_proxy_types():
                continue
            try:
                endpoint = edi_user._get_peppol_proxy_endpoint('2/participant_status')
                proxy_user = edi_user._make_request(f"{edi_user._get_server_url()}{endpoint}")
            except AccountEdiProxyError as e:
                if e.code == 'client_gone':
                    # reset the connection if it was archived/deleted on IAP side
                    edi_user.sudo().company_id._reset_peppol_configuration()
                    edi_user.action_archive()
                else:
                    # don't auto-deregister users on any other errors to avoid settings client-side to states
                    # that are not recoverable without user action if an error on IAP side ever occurs
                    _logger.error('Error while updating Peppol participant status: %s', e)
                continue

            if 'error' in proxy_user:
                error_message = proxy_user['error'].get('message') or proxy_user['error'].get('data', {}).get('message')
                _logger.error('Error while updating Peppol participant status: %s', error_message)
                continue

            edi_user._peppol_process_participant_status(proxy_user)

    # -------------------------------------------------------------------------
    # BUSINESS ACTIONS
    # -------------------------------------------------------------------------

    @handle_demo
    def _peppol_migrate_registration(self):
        """Migrates AWAY from Odoo's SMP."""
        self.ensure_one()
        response = self._call_peppol_proxy(endpoint=self._get_peppol_proxy_endpoint('1/migrate_peppol_registration'))
        if migration_key := response.get('migration_key'):
            self.company_id.sudo().account_peppol_migration_key = migration_key

    def _get_company_details(self):
        self.ensure_one()
        return {
            'peppol_company_name': self.company_id.display_name,
            'peppol_company_vat': self.company_id.vat,
            'peppol_company_street': self.company_id.street,
            'peppol_company_city': self.company_id.city,
            'peppol_company_zip': self.company_id.zip,
            'peppol_country_code': self.company_id.country_id.code,
            'peppol_phone_number': self.company_id.account_peppol_phone_number,
            'peppol_contact_email': self.company_id.account_peppol_contact_email,
            'peppol_migration_key': self.company_id.sudo().account_peppol_migration_key,
        }

    def _peppol_register_sender(self):
        self.ensure_one()
        params = {
            'company_details': self._get_company_details(),
        }
        self._call_peppol_proxy(
            endpoint=self._get_peppol_proxy_endpoint('1/register_sender'),
            params=params,
        )
        self.company_id.account_peppol_proxy_state = 'sender'

    def _peppol_register_receiver(self):
        # remove in master
        self.ensure_one()
        params = {
            'company_details': self._get_company_details(),
            'supported_identifiers': list(self.company_id._peppol_supported_document_types())
        }
        self._call_peppol_proxy(
            endpoint=self._get_peppol_proxy_endpoint('1/register_receiver'),
            params=params,
        )
        self.company_id.account_peppol_proxy_state = 'smp_registration'

    def _peppol_register_sender_as_receiver(self):
        self.ensure_one()
        company = self.company_id

        if company.account_peppol_proxy_state != 'sender':
            # a participant can only try registering as a receiver if they are currently a sender
            peppol_state_translated = dict(company._fields['account_peppol_proxy_state'].selection)[company.account_peppol_proxy_state]
            raise UserError(
                _('Cannot register a user with a %s application', peppol_state_translated))

        edi_identification = self._get_proxy_identification(company, 'peppol')
        self._check_company_on_peppol(company, edi_identification)

        self._call_peppol_proxy(
            endpoint=self._get_peppol_proxy_endpoint('1/register_sender_as_receiver'),
            params={
                'migration_key': company.sudo().account_peppol_migration_key,
                'supported_identifiers': list(company._peppol_supported_document_types())
            },
        )
        # once we sent the migration key over, we don't need it
        # but we need the field for future in case the user decided to migrate away from Odoo
        company.sudo().account_peppol_migration_key = False
        company.account_peppol_proxy_state = 'smp_registration'

        self.env.ref('account_peppol.ir_cron_peppol_get_participant_status')._trigger(at=fields.Datetime.now() + timedelta(hours=1))

    @handle_demo
    def _peppol_deregister_participant(self):
        self.ensure_one()

        proxy_state = None
        try:
            # call _make_request directly because _peppol_get_participant_status()
            # is cron-safe and swallows AccountEdiProxyError.
            endpoint = self._get_peppol_proxy_endpoint('2/participant_status')
            proxy_user = self._make_request(f"{self._get_server_url()}{endpoint}")
            proxy_state = proxy_user.get('peppol_state')
        except AccountEdiProxyError as e:
            # If user no longer exists on IAP side, don't try to fetch docs/statuses (they will fail).
            if e.code not in ['client_gone', 'no_such_user_found']:
                raise
        if proxy_state in ('sender', 'smp_registration', 'receiver'):
            # fetch all documents and message statuses before unlinking the edi user
            # so that the invoices are acknowledged
            self._cron_peppol_get_message_status()
            self._cron_peppol_get_new_documents()
            if not tools.config['test_enable'] and not modules.module.current_test:
                self.env.cr.commit()

            self._call_peppol_proxy(endpoint=self._get_peppol_proxy_endpoint('1/cancel_peppol_registration'))

        self.company_id._reset_peppol_configuration()
        self.unlink()

    def _peppol_deregister_participant_to_sender(self):
        self.ensure_one()

        if self.company_id.account_peppol_proxy_state == 'receiver':
            # fetch all documents and message statuses before unlinking the edi user
            # so that the invoices are acknowledged
            self._cron_peppol_get_message_status()
            self._cron_peppol_get_new_documents()
            if not modules.module.current_test:
                self.env.cr.commit()

        if self.company_id.account_peppol_proxy_state != 'sender':
            self._call_peppol_proxy(endpoint=self._get_peppol_proxy_endpoint('1/unregister_to_sender'))

        self.company_id.account_peppol_proxy_state = 'sender'
        self.company_id.sudo().account_peppol_migration_key = False

    @api.model
    def _peppol_auto_register_services(self, module):
        """Register new document types for all recipient users.

        This function should be run in the post init hook of any module that extends the supported
        document types.

        :param module: Module from which this function is being called, allows us to determine which
            document types are now supported.
        """
        receivers = self.search([
            ('proxy_type', 'in', self._get_peppol_proxy_types()),
            ('company_id.account_peppol_proxy_state', '=', 'receiver')
        ])
        supported_identifiers = list(self.env['res.company']._peppol_modules_document_types().get(module, {}))
        for receiver in receivers:
            try:
                receiver._call_peppol_proxy(
                    receiver._get_peppol_proxy_endpoint('2/add_services'),
                    params={'document_identifiers': supported_identifiers},
                )
            # Broad exception case, so as not to block execution of the rest of the _post_init hook.
            except (AccountEdiProxyError, UserError) as exception:
                _logger.error(
                    'Auto registration of peppol services for module: %s failed on the user: %s, with exception: %s',
                    module, receiver.edi_identification, exception,
                )

    @api.model
    def _peppol_auto_deregister_services(self, module):
        """Unregister a set of document types for all recipient users.

        This function should be run in the uninstall hook of any module that extends the supported
        document types.

        :param module: Module from which this function is being called, allows us to determine which
            document types are no longer supported.
        """
        receivers = self.search([
            ('proxy_type', 'in', self._get_peppol_proxy_types()),
            ('company_id.account_peppol_proxy_state', '=', 'receiver')
        ])
        unsupported_identifiers = list(self.env['res.company']._peppol_modules_document_types().get(module, {}))
        for receiver in receivers:
            try:
                receiver._call_peppol_proxy(
                    receiver._get_peppol_proxy_endpoint('2/remove_services'),
                    params={'document_identifiers': unsupported_identifiers},
                )
            except (AccountEdiProxyError, UserError) as exception:
                _logger.error(
                    'Auto deregistration of peppol services for module: %s failed on the user: %s, with exception: %s',
                    module, receiver.edi_identification, exception,
                )

    def _peppol_get_services(self):
        """Get information from the IAP regarding the Peppol services."""
        self.ensure_one()
        return self._call_peppol_proxy(self._get_peppol_proxy_endpoint('2/get_services'))
